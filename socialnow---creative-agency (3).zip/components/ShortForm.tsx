import React from 'react';

const platforms = [
  { name: 'Snapchat', color: 'bg-yellow-400 text-black', icon: '👻' },
  { name: 'TikTok', color: 'bg-black text-white border border-gray-800', icon: '🎵' },
  { name: 'Meta', color: 'bg-blue-600 text-white', icon: '∞' },
  { name: 'Instagram', color: 'bg-gradient-to-tr from-yellow-400 via-pink-500 to-purple-600 text-white', icon: '📸' }
];

const videos = [
    { id: 1, image: 'https://images.unsplash.com/photo-1611162617474-5b21e879e113?q=80&w=1000&auto=format&fit=crop', views: '2.4M', title: 'Summer Campaign' },
    { id: 2, image: 'https://images.unsplash.com/photo-1611162616475-46e6379c93c6?q=80&w=1000&auto=format&fit=crop', views: '1.8M', title: 'Behind Scenes' },
    { id: 3, image: 'https://images.unsplash.com/photo-1516035069371-29a1b244cc32?q=80&w=1000&auto=format&fit=crop', views: '500K', title: 'Product Launch' },
    { id: 4, image: 'https://images.unsplash.com/photo-1574717024653-61fd2cf4d44c?q=80&w=1000&auto=format&fit=crop', views: '900K', title: 'Influencer Event' },
    { id: 5, image: 'https://images.unsplash.com/photo-1492684223066-81342ee5ff30?q=80&w=1000&auto=format&fit=crop', views: '3.2M', title: 'Festival Vibes' },
];

const ShortForm = () => {
  return (
    <section className="py-24 bg-black relative overflow-hidden">
      {/* Background grain or texture could go here */}
      
      <div className="max-w-7xl mx-auto px-6 text-center mb-16 relative z-10">
         <h2 className="text-3xl md:text-5xl font-black uppercase mb-4">
           Short Form <span className="text-pink-500">Content</span>
         </h2>
         <p className="text-gray-400 max-w-xl mx-auto">
           Op al je favoriete platformen. Wij creëren content die stopt met scrollen.
         </p>
         
         <div className="flex justify-center gap-6 mt-8">
            {platforms.map(p => (
                <div key={p.name} className="flex items-center gap-2">
                    <span className="text-xl">{p.icon}</span>
                    <span className="font-bold text-sm hidden md:block">{p.name}</span>
                </div>
            ))}
         </div>
      </div>

      {/* Marquee Container */}
      <div className="relative w-full overflow-hidden py-10">
        {/* Left fade */}
        <div className="absolute left-0 top-0 bottom-0 w-20 md:w-40 bg-gradient-to-r from-black to-transparent z-20 pointer-events-none"></div>
        {/* Right fade */}
        <div className="absolute right-0 top-0 bottom-0 w-20 md:w-40 bg-gradient-to-l from-black to-transparent z-20 pointer-events-none"></div>

        {/* Sliding Track */}
        <div className="flex w-max animate-marquee pause-on-hover gap-6 md:gap-8 px-6">
          {/* We triple the list to ensure smooth looping on wide screens */}
          {[...videos, ...videos, ...videos].map((item, i) => (
            <div key={`${item.id}-${i}`} className="relative group cursor-pointer w-[280px] md:w-[320px] flex-shrink-0">
              <div className="aspect-[9/16] rounded-2xl overflow-hidden border-4 border-neutral-900 bg-neutral-800 relative shadow-2xl transform transition-transform duration-300 group-hover:scale-105">
                <img 
                  src={item.image} 
                  alt={item.title}
                  className="w-full h-full object-cover opacity-60 group-hover:opacity-100 transition-opacity"
                />
                
                {/* UI Overlay Simulation */}
                <div className="absolute top-4 left-4 right-4 flex justify-between items-center z-10">
                    <div className="w-8 h-1 bg-white/50 rounded-full backdrop-blur"></div>
                    <div className="w-8 h-1 bg-white/30 rounded-full backdrop-blur"></div>
                    <div className="w-8 h-1 bg-white/30 rounded-full backdrop-blur"></div>
                </div>
                
                {/* Info Overlay */}
                <div className="absolute bottom-4 left-4 z-10">
                    <div className="flex items-center gap-2 mb-2">
                        <div className="w-8 h-8 rounded-full bg-gradient-to-br from-pink-500 to-purple-500 border border-white"></div>
                        <span className="text-xs font-bold text-white shadow-black drop-shadow-md">@socialnow</span>
                    </div>
                    <p className="text-sm font-bold text-white mb-1 drop-shadow-md">{item.title}</p>
                    <p className="text-xs text-white/80 flex items-center gap-1">
                        <span>▶ {item.views}</span>
                    </p>
                </div>

                {/* Play Button */}
                <div className="absolute inset-0 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity duration-300">
                    <div className="w-16 h-16 rounded-full bg-white/20 backdrop-blur-md flex items-center justify-center border border-white/30">
                        <div className="w-0 h-0 border-t-[10px] border-t-transparent border-l-[18px] border-l-white border-b-[10px] border-b-transparent ml-1"></div>
                    </div>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default ShortForm;