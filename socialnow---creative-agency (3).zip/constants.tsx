import { Project, TeamMember } from './types';

export const PROJECTS: Project[] = [
  {
    id: '1',
    category: 'ARTIST IMPRESSIONS',
    title: 'Light Art Collection',
    description: 'Voor Light Art Collection en Amsterdam Light Festival maakten we meerdere artist impressions waarin lichtkunstwerken realistisch werden gephotoshopt op diverse locaties. Daarbij werden ook dagbeelden omgezet naar nacht om klanten te overtuigen.',
    image: 'https://images.unsplash.com/photo-1542665094-c353a206412e?q=80&w=2070&auto=format&fit=crop',
    accentColor: 'text-yellow-400',
    layout: 'right',
    stats: [{ label: 'Reach', value: '450K' }, { label: 'Conversion', value: '+12%' }]
  },
  {
    id: '2',
    category: 'BANNERS & SOCIALS',
    title: 'Universal Studios',
    description: 'Voor verschillende filmreleases van UNIVERSAL_NL en SonyPicturesNL ontwikkelden wij on- en offline campagnes die bioscooplanceringen versterkten, herkenbaarheid en groei realiseerden op de socials.',
    image: 'https://images.unsplash.com/photo-1536440136628-849c177e76a1?q=80&w=1925&auto=format&fit=crop',
    accentColor: 'text-pink-500',
    layout: 'left'
  },
  {
    id: '3',
    category: 'BRANDING & VIDEO',
    title: 'RAVEG Hairstyling',
    description: 'Ontwikkelen van volledige branding voor RAVEG – vanaf de start opgebouwd tot een herkenbare en consistente merkidentiteit. Deze werd doorvertaald naar een moderne website en videocontent die de energie en visie van het merk tastbaar maken.',
    image: 'https://images.unsplash.com/photo-1522337660859-02fbefca4702?q=80&w=2069&auto=format&fit=crop',
    accentColor: 'text-cyan-400',
    layout: 'right'
  },
  {
    id: '4',
    category: 'MULTIMEDIA MARKETING',
    title: 'Kids Heroes',
    description: 'Campagne voor Kids Heroes – van planning tot socials, drukwerk en aankleding. Gericht op het enthousiasmeren van kinderen en ouders voor het event. Een 360-graden aanpak voor maximale impact.',
    image: 'https://images.unsplash.com/photo-1628155930542-3c7a64e2c833?q=80&w=2069&auto=format&fit=crop',
    accentColor: 'text-yellow-400',
    layout: 'left'
  },
  {
    id: '5',
    category: 'SOCIAL MEDIA & WEBDESIGN',
    title: 'AZ Alkmaar',
    description: 'Voor AZ ontwierpen wij diverse socialmediaposts en websitevisuals. Denk aan dankuitingen voor spelers, wedstrijdwijzigingen en campagnes voor de jeugdteams. Daarnaast maakten we nieuwe headers en home-achtergronden.',
    image: 'https://images.unsplash.com/photo-1431324155629-1a6deb1dec8d?q=80&w=2070&auto=format&fit=crop',
    accentColor: 'text-white',
    layout: 'right'
  }
];

export const TEAM: TeamMember[] = [
  { id: '1', name: 'Marinus Bergsma', role: 'Art Director', image: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=500&auto=format&fit=crop&q=60' },
  { id: '2', name: 'Sergio Jovovic', role: 'Creative Director', image: 'https://images.unsplash.com/photo-1506794778202-cad84cf45f1d?w=500&auto=format&fit=crop&q=60' },
  { id: '3', name: 'Jos Hollenberg', role: 'Marketer / SEO Specialist', image: 'https://images.unsplash.com/photo-1519085360753-af0119f7cbe7?w=500&auto=format&fit=crop&q=60' },
  { id: '4', name: 'Emma Peperkamp', role: 'Social Media Expert', image: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=500&auto=format&fit=crop&q=60' },
];

export const CLIENT_LOGOS = [
  'MOJO', 'Light Festival', 'Supperclub', 'Chin Chin Club', 'Under Armour', 'Universal'
];
