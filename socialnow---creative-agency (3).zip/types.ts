export interface Project {
  id: string;
  category: string;
  title: string;
  description: string;
  image: string;
  accentColor: string; // e.g., 'text-pink-500'
  layout: 'left' | 'right';
  stats?: { label: string; value: string }[];
}

export interface TeamMember {
  id: string;
  name: string;
  role: string;
  image: string;
}

export interface StatMetric {
  name: string;
  value: number;
  fullMark: number;
}
