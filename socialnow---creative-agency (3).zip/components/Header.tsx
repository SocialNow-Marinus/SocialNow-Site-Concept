import React, { useState } from 'react';
import { Menu, X } from 'lucide-react';

const Header = () => {
  const [isOpen, setIsOpen] = useState(false);

  return (
    <nav className="fixed top-0 left-0 w-full z-50 bg-black/90 backdrop-blur-md border-b border-white/10">
      <div className="max-w-7xl mx-auto px-6 py-4 flex items-center justify-between">
        {/* Logo */}
        <div className="flex items-center gap-2 cursor-pointer">
          <div className="relative w-8 h-8">
            <div className="absolute top-0 left-0 w-5 h-5 bg-cyan-400 rounded-full mix-blend-screen opacity-90 animate-pulse"></div>
            <div className="absolute bottom-0 right-0 w-5 h-5 bg-pink-500 rounded-full mix-blend-screen opacity-90"></div>
          </div>
          <span className="text-2xl font-bold tracking-tight text-white">SocialNow</span>
        </div>

        {/* Desktop Menu */}
        <div className="hidden md:flex items-center gap-8">
          {['HOME', 'PROJECTEN', 'DIENSTEN', 'TEAM', 'CONTACT'].map((item) => (
            <a key={item} href={`#${item.toLowerCase()}`} className="text-sm font-bold text-gray-300 hover:text-white transition-colors tracking-wide">
              {item}
            </a>
          ))}
        </div>

        {/* CTA */}
        <div className="hidden md:block">
          <button className="bg-green-500 hover:bg-green-600 text-black text-xs font-black py-3 px-6 rounded-full uppercase tracking-wider transition-transform hover:scale-105">
            Plan een Strategiecall
          </button>
        </div>

        {/* Mobile Toggle */}
        <button onClick={() => setIsOpen(!isOpen)} className="md:hidden text-white">
          {isOpen ? <X size={28} /> : <Menu size={28} />}
        </button>
      </div>

      {/* Mobile Menu */}
      {isOpen && (
        <div className="md:hidden bg-black absolute top-full left-0 w-full border-b border-white/10 py-4 px-6 flex flex-col gap-4">
          {['HOME', 'PROJECTEN', 'DIENSTEN', 'TEAM', 'CONTACT'].map((item) => (
            <a key={item} href={`#${item.toLowerCase()}`} onClick={() => setIsOpen(false)} className="text-lg font-bold text-gray-300 hover:text-white">
              {item}
            </a>
          ))}
          <button className="bg-green-500 text-black font-bold py-3 px-6 rounded-full uppercase w-full">
            Plan een Strategiecall
          </button>
        </div>
      )}
    </nav>
  );
};

export default Header;