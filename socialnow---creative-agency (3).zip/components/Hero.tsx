import React from 'react';
import { ArrowDown, Play } from 'lucide-react';
import { CLIENT_LOGOS } from '../constants';

const Hero = () => {
  return (
    <section className="relative pt-32 pb-20 overflow-hidden min-h-screen flex flex-col justify-center">
      {/* Background Elements */}
      <div className="absolute top-20 right-0 w-96 h-96 bg-yellow-400 rounded-full blur-[150px] opacity-20"></div>
      <div className="absolute bottom-20 left-0 w-96 h-96 bg-pink-600 rounded-full blur-[150px] opacity-20"></div>

      <div className="max-w-7xl mx-auto px-6 z-10 text-center">
        <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full border border-white/20 bg-white/5 backdrop-blur mb-8">
           <span className="w-2 h-2 rounded-full bg-green-500 animate-pulse"></span>
           <span className="text-xs font-bold tracking-widest uppercase text-gray-300">New Agency Website</span>
        </div>

        <h1 className="text-6xl md:text-8xl font-black tracking-tighter mb-8 leading-[0.9]">
          THE NEXT <br />
          <span className="text-transparent bg-clip-text bg-gradient-to-r from-cyan-400 via-white to-pink-500">
            GENERATION
          </span> <br />
          OF BRANDING
        </h1>
        
        <p className="max-w-2xl mx-auto text-gray-400 text-lg md:text-xl mb-12 font-light">
          Maak je merk onmisbaar met high-end artworks, unieke motion designs en opvallende fotografie gebundeld met een doeltreffende on- en offline marketingstrategie.
        </p>

        <div className="flex flex-col md:flex-row items-center justify-center gap-4">
          <button className="bg-white text-black font-black py-4 px-10 rounded-full uppercase tracking-wider hover:bg-gray-200 transition-colors flex items-center gap-2">
            Kennismaken
            <ArrowDown size={18} />
          </button>
          <button className="border border-white/20 hover:border-white text-white font-bold py-4 px-10 rounded-full uppercase tracking-wider transition-colors flex items-center gap-2">
            <Play size={18} fill="currentColor" />
            Showreel 2024
          </button>
        </div>
      </div>

      {/* Client Logos Marquee */}
      <div className="mt-24 border-y border-white/10 bg-black/50 py-10 relative">
        <div className="overflow-hidden whitespace-nowrap">
          <div className="inline-block animate-marquee">
            {[...CLIENT_LOGOS, ...CLIENT_LOGOS, ...CLIENT_LOGOS].map((client, i) => (
              <span key={i} className="mx-12 text-2xl md:text-4xl font-black text-gray-800 uppercase hover:text-white transition-colors cursor-default">
                {client}
              </span>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
};

export default Hero;