import React from 'react';
import Header from './components/Header';
import Hero from './components/Hero';
import ProjectSection from './components/ProjectSection';
import StatsSection from './components/StatsSection';
import ShortForm from './components/ShortForm';
import TeamSection from './components/TeamSection';
import Footer from './components/Footer';

function App() {
  return (
    <div className="bg-black min-h-screen text-white selection:bg-pink-500 selection:text-white">
      <Header />
      <main>
        <Hero />
        <ProjectSection />
        <StatsSection />
        <ShortForm />
        <TeamSection />
      </main>
      <Footer />
    </div>
  );
}

export default App;