import React, { useState, useEffect, useRef } from 'react';
import { AreaChart, Area, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, BarChart, Bar, Cell } from 'recharts';

const dataGrowth = [
  { name: 'Jan', reach: 4000 },
  { name: 'Feb', reach: 3000 },
  { name: 'Mar', reach: 2000 },
  { name: 'Apr', reach: 2780 },
  { name: 'May', reach: 1890 },
  { name: 'Jun', reach: 2390 },
  { name: 'Jul', reach: 3490 },
  { name: 'Aug', reach: 5000 },
  { name: 'Sep', reach: 6500 },
  { name: 'Oct', reach: 8000 },
  { name: 'Nov', reach: 9200 },
  { name: 'Dec', reach: 11000 },
];

const dataEngagement = [
  { name: 'Instagram', value: 85 },
  { name: 'TikTok', value: 92 },
  { name: 'LinkedIn', value: 65 },
  { name: 'YouTube', value: 45 },
];

const COLORS = ['#EC4899', '#22D3EE', '#FACC15', '#A855F7'];

// Component for counting up numbers
const AnimatedCounter = ({ value, label, color, isVisible }: { value: string, label: string, color: string, isVisible: boolean }) => {
  const [count, setCount] = useState(0);
  
  // Parse the numeric part (e.g. "2M+" -> 2)
  const target = parseFloat(value.replace(/[^0-9.]/g, '')) || 0;
  // Keep the suffix (e.g. "M+")
  const suffix = value.replace(/[0-9.]/g, '');

  useEffect(() => {
    if (!isVisible) return;

    let startTimestamp: number | null = null;
    const duration = 2000; // 2 seconds animation

    const step = (timestamp: number) => {
      if (!startTimestamp) startTimestamp = timestamp;
      const progress = Math.min((timestamp - startTimestamp) / duration, 1);
      
      // Ease out quart function for smooth landing
      const easeOut = (x: number): number => 1 - Math.pow(1 - x, 4);
      
      setCount(target * easeOut(progress));
      
      if (progress < 1) {
        window.requestAnimationFrame(step);
      }
    };
    
    window.requestAnimationFrame(step);
  }, [isVisible, target]);

  return (
    <div className="text-center p-6 rounded-2xl bg-white/5 hover:bg-white/10 transition-colors group">
      <div className={`text-4xl md:text-6xl font-black ${color} mb-2 transform group-hover:scale-110 transition-transform`}>
        {isVisible ? (
           // If target is integer, show integer, else show 1 decimal if needed
           <span>{Number.isInteger(target) ? Math.floor(count) : count.toFixed(1)}{suffix}</span>
        ) : '0'}
      </div>
      <div className="text-sm uppercase tracking-widest font-bold text-gray-400 group-hover:text-white transition-colors">
        {label}
      </div>
    </div>
  );
};

const StatsSection = () => {
  const [isVisible, setIsVisible] = useState(false);
  const sectionRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          setIsVisible(true);
        }
      },
      { threshold: 0.1 } // Trigger when 10% visible
    );

    if (sectionRef.current) {
      observer.observe(sectionRef.current);
    }

    return () => observer.disconnect();
  }, []);

  return (
    <section ref={sectionRef} className="py-24 bg-neutral-900 border-y border-white/5">
      <div className="max-w-7xl mx-auto px-6">
        <div className="mb-16 text-center">
          <h2 className="text-4xl md:text-6xl font-black uppercase mb-4">
            <span className="text-cyan-400">Data</span> Driven Results
          </h2>
          <p className="text-gray-400">We don't just make it look good, we make it perform.</p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12">
          
          {/* Chart 1: Growth */}
          <div className="bg-black/40 p-8 rounded-3xl border border-white/10 transform transition-all hover:border-pink-500/30">
            <h3 className="text-xl font-bold mb-6 flex items-center gap-2">
              <span className="w-2 h-2 bg-pink-500 rounded-full animate-pulse"></span>
              Audience Growth Year-over-Year
            </h3>
            <div className="h-[300px] w-full">
              <ResponsiveContainer width="100%" height="100%">
                {/* Force re-render with key to trigger animation when visible */}
                <AreaChart key={isVisible ? 'visible-area' : 'hidden-area'} data={dataGrowth} margin={{ top: 10, right: 0, left: -20, bottom: 0 }}>
                  <defs>
                    <linearGradient id="colorReach" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="5%" stopColor="#ec4899" stopOpacity={0.8}/>
                      <stop offset="95%" stopColor="#ec4899" stopOpacity={0}/>
                    </linearGradient>
                  </defs>
                  <CartesianGrid strokeDasharray="3 3" stroke="#333" vertical={false} />
                  <XAxis dataKey="name" stroke="#666" tick={{fill: '#666', fontSize: 12}} />
                  <YAxis stroke="#666" tick={{fill: '#666', fontSize: 12}} />
                  <Tooltip 
                    contentStyle={{ backgroundColor: '#000', border: '1px solid #333', borderRadius: '8px' }}
                    itemStyle={{ color: '#ec4899' }}
                    animationDuration={500}
                  />
                  <Area 
                    type="monotone" 
                    dataKey="reach" 
                    stroke="#ec4899" 
                    strokeWidth={3} 
                    fillOpacity={1} 
                    fill="url(#colorReach)" 
                    isAnimationActive={isVisible}
                    animationDuration={2000}
                  />
                </AreaChart>
              </ResponsiveContainer>
            </div>
          </div>

          {/* Chart 2: Engagement */}
          <div className="bg-black/40 p-8 rounded-3xl border border-white/10 transform transition-all hover:border-cyan-400/30">
            <h3 className="text-xl font-bold mb-6 flex items-center gap-2">
              <span className="w-2 h-2 bg-cyan-400 rounded-full animate-pulse"></span>
              Platform Engagement Rate (%)
            </h3>
            <div className="h-[300px] w-full">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart key={isVisible ? 'visible-bar' : 'hidden-bar'} data={dataEngagement}>
                  <CartesianGrid strokeDasharray="3 3" stroke="#333" vertical={false} />
                  <XAxis dataKey="name" stroke="#666" tick={{fill: '#666', fontSize: 12}} />
                  <YAxis stroke="#666" tick={{fill: '#666', fontSize: 12}} />
                  <Tooltip 
                     cursor={{fill: 'rgba(255,255,255,0.05)'}}
                     contentStyle={{ backgroundColor: '#000', border: '1px solid #333', borderRadius: '8px' }}
                  />
                  <Bar dataKey="value" radius={[8, 8, 0, 0]} isAnimationActive={isVisible} animationDuration={2000} animationBegin={500}>
                    {dataEngagement.map((entry, index) => (
                      <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                    ))}
                  </Bar>
                </BarChart>
              </ResponsiveContainer>
            </div>
          </div>
        </div>

        {/* Big Numbers with Counting Animation */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-8 mt-16">
          {[
            { label: 'Followers', value: '2M+', color: 'text-pink-500' },
            { label: 'Likes', value: '500M+', color: 'text-cyan-400' },
            { label: 'Reached', value: '800M+', color: 'text-yellow-400' },
            { label: 'Campaigns', value: '150+', color: 'text-white' },
          ].map((stat, i) => (
            <AnimatedCounter 
                key={i} 
                value={stat.value} 
                label={stat.label} 
                color={stat.color} 
                isVisible={isVisible} 
            />
          ))}
        </div>
      </div>
    </section>
  );
};

export default StatsSection;