import React from 'react';
import { TEAM } from '../constants';

const TeamSection = () => {
  return (
    <section id="team" className="py-24 bg-white text-black">
      <div className="max-w-7xl mx-auto px-6">
        <div className="text-center mb-16">
          <h2 className="text-4xl md:text-6xl font-black uppercase mb-6">Wij Zijn SocialNow!</h2>
          <p className="max-w-2xl mx-auto text-gray-600 text-lg">
            Ons verhaal begint in 2018, in Amsterdam. Als jonge enthousiastelingen merkten we dat bedrijven vaak de neiging hadden om zich te concentreren op de verkeerde aspecten.
          </p>
          <a href="#" className="inline-block mt-8 text-black font-bold uppercase tracking-wider border-b-2 border-black pb-1 hover:text-pink-600 hover:border-pink-600 transition-colors">
             Ons Team &rarr;
          </a>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
          {TEAM.map((member) => (
            <div key={member.id} className="group relative">
              <div className="aspect-square overflow-hidden rounded-xl bg-gray-100">
                <img 
                  src={member.image} 
                  alt={member.name} 
                  className="w-full h-full object-cover filter grayscale group-hover:grayscale-0 transition-all duration-500 group-hover:scale-105"
                />
              </div>
              <div className="absolute bottom-4 left-4 right-4 translate-y-2 opacity-0 group-hover:translate-y-0 group-hover:opacity-100 transition-all duration-300">
                <div className="bg-white/90 backdrop-blur p-4 rounded-lg shadow-lg">
                  <h3 className="font-bold text-lg uppercase leading-none mb-1">{member.name}</h3>
                  <p className="text-xs text-gray-500 uppercase tracking-wider">{member.role}</p>
                </div>
              </div>
            </div>
          ))}
        </div>
        
        <div className="mt-16 text-center">
             <button className="border-2 border-black px-10 py-4 rounded-full font-black uppercase hover:bg-black hover:text-white transition-all">
                Kennismaken
             </button>
        </div>
      </div>
    </section>
  );
};

export default TeamSection;