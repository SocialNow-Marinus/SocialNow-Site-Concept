import React from 'react';
import { Instagram, Twitter, Facebook, Linkedin, Mail, Phone, MapPin } from 'lucide-react';

const Footer = () => {
  return (
    <footer id="contact" className="bg-black pt-24 pb-12 border-t border-white/10">
      <div className="max-w-7xl mx-auto px-6">
        
        {/* Call to Action Area */}
        <div className="text-center mb-24 relative">
             <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-64 h-64 bg-pink-600 rounded-full blur-[100px] opacity-20 pointer-events-none"></div>
             <h2 className="text-4xl md:text-7xl font-black uppercase mb-8 relative z-10">
                Lanceer jouw <span className="text-transparent bg-clip-text bg-gradient-to-r from-yellow-400 to-pink-500">Succes!</span> 🚀
             </h2>
             <button className="relative z-10 border border-white hover:bg-white hover:text-black text-white font-bold py-4 px-12 rounded-full uppercase tracking-wider transition-all">
                Vrijblijvend Sparren &gt;
             </button>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-4 gap-12 mb-16 border-b border-white/10 pb-16">
          <div className="md:col-span-1">
             <div className="flex items-center gap-2 mb-6">
                <div className="relative w-6 h-6">
                    <div className="absolute top-0 left-0 w-4 h-4 bg-cyan-400 rounded-full"></div>
                    <div className="absolute bottom-0 right-0 w-4 h-4 bg-pink-500 rounded-full mix-blend-screen"></div>
                </div>
                <span className="text-xl font-bold">SocialNow</span>
            </div>
            <div className="flex gap-4">
                <a href="#" className="w-10 h-10 rounded-full bg-white/10 flex items-center justify-center hover:bg-white hover:text-black transition-colors"><Facebook size={18} /></a>
                <a href="#" className="w-10 h-10 rounded-full bg-white/10 flex items-center justify-center hover:bg-white hover:text-black transition-colors"><Instagram size={18} /></a>
                <a href="#" className="w-10 h-10 rounded-full bg-white/10 flex items-center justify-center hover:bg-white hover:text-black transition-colors"><Twitter size={18} /></a>
                <a href="#" className="w-10 h-10 rounded-full bg-white/10 flex items-center justify-center hover:bg-white hover:text-black transition-colors"><Linkedin size={18} /></a>
            </div>
          </div>

          <div>
            <h4 className="font-bold uppercase mb-6 tracking-widest text-sm text-gray-500">Contact</h4>
            <ul className="space-y-4 text-gray-300">
                <li className="flex items-center gap-3 hover:text-white transition-colors cursor-pointer">
                    <Mail size={16} className="text-pink-500" />
                    info@socialnow.nl
                </li>
                <li className="flex items-center gap-3 hover:text-white transition-colors cursor-pointer">
                    <Phone size={16} className="text-cyan-400" />
                    06 37 40 45 77
                </li>
            </ul>
          </div>

          <div>
            <h4 className="font-bold uppercase mb-6 tracking-widest text-sm text-gray-500">Menu</h4>
            <ul className="space-y-2 text-gray-300">
                {['Werk', 'Diensten', 'Werkwijze', 'Over Ons', 'Contact'].map(item => (
                    <li key={item}><a href="#" className="hover:text-pink-500 transition-colors uppercase text-sm font-bold">{item}</a></li>
                ))}
            </ul>
          </div>

          <div>
            <h4 className="font-bold uppercase mb-6 tracking-widest text-sm text-gray-500">Vestiging</h4>
             <ul className="space-y-2 text-gray-300">
                <li className="flex items-start gap-3">
                    <MapPin size={16} className="text-yellow-400 mt-1 shrink-0" />
                    <span>
                        Amstelstraat 43 G<br/>
                        1017DA Amsterdam<br/>
                        Nederland
                    </span>
                </li>
             </ul>
          </div>
        </div>

        <div className="flex flex-col md:flex-row justify-between items-center text-xs text-gray-600 uppercase tracking-widest">
            <p>Copyright © 2024, SocialNow All Rights Reserved</p>
            <div className="flex gap-6 mt-4 md:mt-0">
                <a href="#" className="hover:text-white">Algemene Voorwaarden</a>
                <a href="#" className="hover:text-white">Privacy</a>
            </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;